var monkey_running,bananaimage,jungleimage,stoneimge;
var monkey,banana,stone,jungle,ground;
var score;
var foodGroup,stoneGroup;

function preload(){
  monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaimage = loadImage("banana.png");
  jungleimage = loadImage("jungle.jpg");
  stoneimage = loadImage("stone.png");

}

function setup() {
  createCanvas(400, 400);
  monkey = createSprite(50,300,40,40);
  monkey.addAnimation("running",monkey_running);
  monkey.scale = 0.5;
  
  jungle = createSprite (200,200,400,400);
  jungle.addImage (jungleimage);
  jungle.x = ground.width /2;
  jungle.velocityX = -4;
  
  ground = createSprite(200,310,400,5);
  ground.visible = false;
  
  foodGroup  = new Group();
  stoneGroup = new Group();
  
  score = 0;
}

function draw() {
  background(220);
  
  if(keydown("space")&&monkey.y>250){
    monkey.velocityY = -11;
    monkey.velocityY = monkey.velocityY + 0.9;
     }
  food();
  spawnObstacles();
    text("Score: "+ score, 500,50);

  drawSprites();
}

 function food(){
 if (frameCount % 60 === 0) {
    var banana = createSprite(400,120,40,10);
    banana.y = Math.round(random(150,250));
    banana.addImage(bananaimage);
    banana.scale = 0.5;
    banana.velocityX = -3;
    
     //assign lifetime to the variable
    banana.lifetime = 200;
    //add each cloud to the group
    foodGroup.add(banana);
  }
   if (foodGroup.istouching(monkey)){
   score = score + 10;
     foodGroup.destroyEach();
     switch(score){
       case 10: monkey.scale = 0.12;
         break;
      case 20: monkey.scale = 0.14;
         break; 
      case 30: monkey.scale = 0.16;
         break;
       case 40: monkey.scale = 0.18;
         break;   
         default : break;
     }}
 }

function spawnObstacles() {
  if(frameCount % 80 === 0) {
    var stone = createSprite(400,310,10,40);
    stone.velocityX = -4;
        stone.addImage(stoneimge);
    stone.scale = 0.5;
  //assign lifetime to the variable
    stone.lifetime = 200;
    //add each cloud to the group
    stoneGroup.add(stone);
  }
if (stoneGroup.istouching(monkey)){
monkey.scale = 0.2;

}


  }



